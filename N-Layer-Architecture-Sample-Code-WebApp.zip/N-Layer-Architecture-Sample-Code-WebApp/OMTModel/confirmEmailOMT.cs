﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMTModel
{
    public class confirmEmailOMT
    {
        public string Email { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMTModel
{
    public class OTPConfirmOMT
    {
        public string Email { get; set; }
        public string OTP { get; set; }
    }
}

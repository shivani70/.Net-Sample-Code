﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OMTModel
{

    
        public enum UserType
        {
            SuperAdmin, Admin, Examiner, Student
        }
    
}
